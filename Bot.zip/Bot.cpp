#include "Bot.hpp"
Bot::Bot() :neuron(3), pos(rand() % width, rand() % height)
{
	MaxHunger = (double)(rand() % 101) / 10;
	Hunger = 0.5*MaxHunger;
	speed = (float)(rand() % 31) / 15 + 0.1f;
}
Bot Bot::Razm(Bot & second)
{
	Bot ret;
	for (int i = 0; i < ret.neuron.weight.size(); i++)
		ret.neuron.weight[i] = (rand() % 2 == 0) ? neuron.weight[i] : second.neuron.weight[i] + (double)(rand() % 11) / 10.f - 0.5f;
	Hunger -= 0.4999999f * MaxHunger;
	second.Hunger -= 0.4999999f * second.MaxHunger;
	ret.pos = pos;
	ret.pos.x += (float)(rand() % 11 - 5);
	ret.pos.y += (float)(rand() % 11 - 5);
	/*pos.x = rand() % width;
	pos.y = rand() % height;*/
	//ret.pos = pos;
	return ret;
}
Bot& Bot::operator=(const Bot& right) {
	//if (this == &right) {
	//	return *this;
	//}
	this->Hunger = right.Hunger;
	this->speed = right.speed;
	this->pos = right.pos;
	this->targ = right.targ;
	this->state = right.state;
	this->MaxHunger = right.MaxHunger;
	neuron = right.neuron;
	return *this;//o
}//a1
bool Bot::operator==(const Bot& b)//oa 1 2 34 5W1mail
{
	return (pos == b.pos) && (b.neuron.weight == neuron.weight);
}
bool Bot::operator!=(const Bot& b)
{
	return !(*this==b);
}
void Bot::Update(vector<sf::Vector2f>& fruits, BOT& bot,int & itn)
{
	Hunger -= 0.01f;
	if (Hunger > MaxHunger)
		Hunger = MaxHunger;
	if (Hunger <= 0.f) return;
	{
		vector<double> lens_fr(fruits.size());
		for (int i = 0; i < fruits.size(); i++)
			lens_fr[i] = len(fruits[i], pos);
		vector<double> lens_bt(bot.size()-1);
		for (int i = 0; i < bot.size(); i++)
			if (itn != i)
				lens_bt[i - (i > itn)] = len(bot[i].pos, pos);
		vector<double>::iterator m_fr = std::min_element(lens_fr.begin(), lens_fr.end());
		vector<double>::iterator m_bt = std::min_element(lens_bt.begin(), lens_bt.end());
		double result = neuron.process({ (m_fr	== lens_fr.end())? FLT_MAX :*m_fr,
			(m_bt==lens_bt.end())? FLT_MAX :*m_bt,(Hunger / MaxHunger) });
		if (result > 0.5)//eat
		{
			int dist = std::distance(lens_bt.begin(), m_bt);
			if (m_fr == lens_fr.end())
				targ = dist + (dist >= itn);
			else if (m_bt == lens_bt.end())
				targ = std::distance(lens_fr.begin(), m_fr);
			else
			targ = (*m_fr < *m_bt) ? std::distance(lens_fr.begin(), m_fr) :
				//(dist - (dist <= itn));
				(dist + (dist >= itn));
			//if ((dist <= itn) && !(*m_fr < *m_bt))
				//itn--;
			state = Eat;
		}
		else
		{
			targ = std::distance(lens_bt.begin(), m_bt) + (std::distance(lens_bt.begin(), m_bt) <= itn);
			state = Robot;
		}
		double angle;
		sf::Vector2f tar = (state == Eat) ? ((*m_fr < *m_bt)?fruits[targ]:bot[targ].pos): bot[targ].pos;
		angle = atan2(double(tar.y - pos.y), double(tar.x - pos.x));
		sf::Vector2f move(cos(angle), sin(angle));
		move *= speed;
		if (len(tar, pos) > len(move, sf::Vector2f(0, 0)))
			this->pos += move;
		else
			this->pos = tar;
		if (pos == tar)
		{
			if (state == Eat)
			{
				if (*m_fr < *m_bt)
				{
					fruits.erase((m_fr - lens_fr.begin() + fruits.begin()));
					Hunger += 0.5f * MaxHunger;
				}
				else
					if (Hunger > bot[targ].Hunger)
				{
					Hunger += bot[targ].Hunger;
					bot.erase((targ + bot.begin()));
					int tr = itn;//for debug
					if(itn != 0)
						itn -= (itn >= targ);
				}
			}
			else if (state == Robot)
			{
				bot.push_back(Razm(bot[targ]));
			}
		}
	}
	/*Hunger -= (rand() % 10) / (double)2000;
	if (Hunger <= 0)
	{
		state = -1;
		return -1;
	}
	if (Hunger <= 0.5f * MaxHunger)
	{
		if (state == 2)
			for (int i = 0; i < bot.size(); i++)
			{
				if (bot[i].target == &pos)
				{
					bot[i].state = 0;
					bot[i].target = &bot[i].pos;
					break;
				}
			}
		state = 1;
		vector<double> targets;
		for (sf::Vector2f f : fruits)
		{
			vector<double> data = { len(f,this->pos),Hunger };
			targets.push_back(neuron.process(data));
		}
		target = &fruits[(max_element(targets.begin(), targets.end()) - targets.begin())];
	}
	if (Hunger >= 0.75f * MaxHunger && state == 0)
	{
		return 2;
	}
	else if (state == 1)
	{
		if (this->pos == *target)
		{
			Hunger = MaxHunger;
			fruits.erase(std::find(fruits.begin(), fruits.end(), pos));
		}
	}
	else if (state == 2)
	{
		target = &bot[targ].pos;
		if (this->pos == *target)
		{
			for (int i = 0; i < bot.size(); i++)
			{
				if (&bot[i].pos == target && itn != i)
				{
					bot.push_back(Razm(bot[i]));
					bot[i].state = 0;
					state = 0;
					target = &pos;
				}
			}
		}
	}
	else if (state == 0)
		target = &pos;
	sf::Vector2f tar = *target;
	double angle = atan2(double(tar.y - pos.y), double(tar.x - pos.x));
	sf::Vector2f move(cos(angle), sin(angle));
	if (len(tar, pos) > len(move, sf::Vector2f(0, 0)))
		this->pos += (move * speed);
	else
		this->pos = *target;
	return 1023;*/
}