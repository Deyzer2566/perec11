#include "Bot.hpp"
#define _KOEF 0.3f
Bot::Bot() :neuron(1), pos(rand() % width, rand() % height), neuron2(1)
{
	MaxHunger = (double)(rand() % 101) / 10;
	Hunger = 0.5*MaxHunger;
	speed = (float)(rand() % 31) / 15 + 0.1f;
}
Bot Bot::Razm(Bot & second)
{
	Bot ret;
	for (int i = 0; i < ret.neuron.weight.size(); i++)
		ret.neuron.weight[i] = (rand() % 2 == 0) ? neuron.weight[i] : \
		second.neuron.weight[i] + (double)(rand() % 11) / 10.f - 0.5f;
	Hunger -= _KOEF * MaxHunger;
	second.Hunger -= _KOEF * second.MaxHunger;
	MaxHunger += (double)((rand() % 2) - 1) * _KOEF;
	ret.pos = pos;
	ret.pos.x += (float)(rand() % 101 - 50);
	ret.pos.y += (float)(rand() % 101 - 50);
	/*pos.x = rand() % width;
	pos.y = rand() % height;*/
	//ret.pos = pos;
	return ret;
}

Bot& Bot::operator=(const Bot& right) {
	//if (this == &right) {
	//	return *this;
	//}
	this->Hunger = right.Hunger;
	this->speed = right.speed;
	this->pos = right.pos;
	this->target = right.target;
	this->state = right.state;
	this->MaxHunger = right.MaxHunger;
	neuron = right.neuron;
	return *this;//o
}//a1
bool Bot::operator==(const Bot& b)//oa 1 2 34 5W1mail
{
	return (pos == b.pos) && (b.neuron.weight == neuron.weight);
}
bool Bot::operator!=(const Bot& b)
{
	return !(*this==b);
}
template <class T>
T getMin(std::vector<T> el)
{
	T m = (T)INT_MAX;
	for (int i = 0; i < el.size(); i++)
		if (el[i] < m)
			m = el[i];
	return m;
}
void Bot::update(vector<sf::Vector2f>& fruits, BOT& bot,int & itn)
{
	Hunger -= 0.01f;
	if (Hunger > MaxHunger)
		Hunger = MaxHunger;
	if (Hunger <= 0.f)
		return;
	/*
	vector<double> lens_fr(fruits.size());
	for (int i = 0; i < fruits.size(); i++)
		lens_fr[i] = len(fruits[i], pos);
	vector<double> lens_bt(bot.size()-1);
	for (int i = 0; i < bot.size(); i++)
		if (itn != i)
			lens_bt[i - (i > itn)] = len(bot[i].pos, pos);
	vector<double>::iterator m_fr = std::min_element(lens_fr.begin(), lens_fr.end());
	vector<double>::iterator m_bt = std::min_element(lens_bt.begin(), lens_bt.end());*/
		
	double result = neuron.process({(Hunger / MaxHunger)});
	sf::Vector2f tar;
	if (result > 0.5)//eat
	{
		state = Eat;
		vector<double> targ(fruits.size()+bot.size()-1);
		for (int i = 0; i < fruits.size() + bot.size() - 1; i++)
		{
			if (i == itn)
				i--;
			if (i < fruits.size())
				targ[i] = neuron2.process({ len(pos, fruits[i]) });
			else
				targ[i] = neuron2.process({ len(pos, bot[i - fruits.size()].pos) });
		}
		target = std::max_element(targ.begin(), targ.end())-targ.begin();
		if (target < fruits.size())
		{
			tar = fruits[target];
		}
		else
		{
			tar = bot[target - fruits.size()].pos;
		}
	}
	//stop here
	else
	{
		target = std::distance(lens_bt.begin(), m_bt) + (std::distance(lens_bt.begin(), m_bt) <= itn);
		state = Robot;
	}
	double angle;
	angle = atan2(double(tar.y - pos.y), double(tar.x - pos.x));
	sf::Vector2f move(cos(angle), sin(angle));
	move *= speed;
	if (len(tar, pos) > len(move, sf::Vector2f(0, 0)))
		this->pos += move;
	else
		this->pos = tar;
	if (pos == tar)
	{
		if (state == Eat)
		{
			if (*m_fr < *m_bt)
			{
				fruits.erase((m_fr - lens_fr.begin() + fruits.begin()));
				Hunger += 0.5f * MaxHunger;
			}
			else
				if (Hunger > bot[target].Hunger)
			{
				Hunger += bot[target].Hunger;
				bot.erase((target + bot.begin()));
				int tr = itn;//for debug
				if(itn != 0)
					itn -= (itn >= target);
			}
		}
		else if (state == Robot)
		{
			bot.push_back(Razm(bot[target]));
		}
	}
	/*Hunger -= (rand() % 10) / (double)2000;
	if (Hunger <= 0)
	{
		state = -1;
		return -1;
	}
	if (Hunger <= 0.5f * MaxHunger)
	{
		if (state == 2)
			for (int i = 0; i < bot.size(); i++)
			{
				if (bot[i].target == &pos)
				{
					bot[i].state = 0;
					bot[i].target = &bot[i].pos;
					break;
				}
			}
		state = 1;
		vector<double> targets;
		for (sf::Vector2f f : fruits)
		{
			vector<double> data = { len(f,this->pos),Hunger };
			targets.push_back(neuron.process(data));
		}
		target = &fruits[(max_element(targets.begin(), targets.end()) - targets.begin())];
	}
	if (Hunger >= 0.75f * MaxHunger && state == 0)
	{
		return 2;
	}
	else if (state == 1)
	{
		if (this->pos == *target)
		{
			Hunger = MaxHunger;
			fruits.erase(std::find(fruits.begin(), fruits.end(), pos));
		}
	}
	else if (state == 2)
	{
		target = &bot[target].pos;
		if (this->pos == *target)
		{
			for (int i = 0; i < bot.size(); i++)
			{
				if (&bot[i].pos == target && itn != i)
				{
					bot.push_back(Razm(bot[i]));
					bot[i].state = 0;
					state = 0;
					target = &pos;
				}
			}
		}
	}
	else if (state == 0)
		target = &pos;
	sf::Vector2f tar = *target;
	double angle = atan2(double(tar.y - pos.y), double(tar.x - pos.x));
	sf::Vector2f move(cos(angle), sin(angle));
	if (len(tar, pos) > len(move, sf::Vector2f(0, 0)))
		this->pos += (move * speed);
	else
		this->pos = *target;
	return 1023;*/
}